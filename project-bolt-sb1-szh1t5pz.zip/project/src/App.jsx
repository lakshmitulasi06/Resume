import React from 'react';
import { Header } from './components/Header';
import { Contact } from './components/Contact';
import { Education } from './components/Education';
import { Skills } from './components/Skills';
import { Certificates } from './components/Certificates';
import { ExtraCurricular } from './components/ExtraCurricular';
import { Hobbies } from './components/Hobbies';
import { Footer } from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Left Column */}
          <div className="md:col-span-1">
            <Contact />
            <Skills />
            <Hobbies />
          </div>

          {/* Right Column */}
          <div className="md:col-span-2">
            <Education />
            <Certificates />
            <ExtraCurricular />
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}

export default App;