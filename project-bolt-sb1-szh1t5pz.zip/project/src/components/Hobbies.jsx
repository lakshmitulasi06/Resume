import React from 'react';

export function Hobbies() {
  const hobbies = [
    "Painting",
    "Arts/Crafts",
    "Listening to music"
  ];

  return (
    <section className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-2xl font-bold mb-4 text-gray-800">Hobbies</h2>
      <ul className="space-y-2">
        {hobbies.map((hobby, index) => (
          <li key={index}>{hobby}</li>
        ))}
      </ul>
    </section>
  );
}