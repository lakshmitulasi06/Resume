import React from 'react';

export function Certificates() {
  const certificates = [
    "Certified in Python programming from - 2023 - a quiz based on coding skills and general knowledge",
    "Certification of 100 days batch in webcode"
  ];

  return (
    <section className="bg-white p-6 rounded-lg shadow-md mb-6">
      <h2 className="text-2xl font-bold mb-4 text-gray-800">Certificates</h2>
      <ul className="list-disc pl-5 space-y-2">
        {certificates.map((cert, index) => (
          <li key={index}>{cert}</li>
        ))}
      </ul>
    </section>
  );
}