import React from 'react';

export function Education() {
  const educationData = [
    {
      degree: "Bachelor of Technology in Artificial Intelligence and Data Science",
      institution: "Sri Indu Engineering College for Women",
      period: "2019-2023",
      grade: "CGPA: 8.74"
    },
    {
      degree: "Intermediate",
      institution: "Sri Chaitanya Junior College",
      period: "2017-2019",
      grade: "CGPA: 9.13"
    },
    {
      degree: "SSC",
      institution: "Pratibha E.M School",
      period: "2017",
      grade: "CGPA: 9.00"
    }
  ];

  return (
    <section className="bg-white p-6 rounded-lg shadow-md mb-6">
      <h2 className="text-2xl font-bold mb-4 text-gray-800">Education</h2>
      <div className="space-y-4">
        {educationData.map((edu, index) => (
          <div key={index}>
            <h3 className="text-xl font-semibold">{edu.degree}</h3>
            <p className="text-gray-600">
              {edu.institution}, {edu.period} - {edu.grade}
            </p>
          </div>
        ))}
      </div>
    </section>
  );
}