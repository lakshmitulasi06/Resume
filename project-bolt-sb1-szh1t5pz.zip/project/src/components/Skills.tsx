import React from 'react';

export function Skills() {
  const skills = [
    "HTML, CSS, JavaScript",
    "Python",
    "Java",
    "Data Structures"
  ];

  return (
    <section className="bg-white p-6 rounded-lg shadow-md mb-6">
      <h2 className="text-2xl font-bold mb-4 text-gray-800">Skills</h2>
      <ul className="space-y-2">
        {skills.map((skill, index) => (
          <li key={index}>{skill}</li>
        ))}
      </ul>
    </section>
  );
}