import React from 'react';

export function ExtraCurricular() {
  const activities = [
    "Participated in NSS circle and a team of 5 members on fire Quality Index",
    "Participated in Hackathon 6.0"
  ];

  return (
    <section className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-2xl font-bold mb-4 text-gray-800">Extra-Curricular Activities</h2>
      <ul className="list-disc pl-5 space-y-2">
        {activities.map((activity, index) => (
          <li key={index}>{activity}</li>
        ))}
      </ul>
    </section>
  );
}