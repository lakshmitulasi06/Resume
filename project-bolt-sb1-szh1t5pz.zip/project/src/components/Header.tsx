import React from 'react';

export function Header() {
  return (
    <header className="bg-gray-800 text-white py-8">
      <div className="container mx-auto px-4">
        <h1 className="text-4xl font-bold text-center">AREPALLI LAKSHMI TULASI</h1>
        <p className="text-center mt-2 text-gray-300">
          Web Developer | HTML, CSS, JavaScript | arepallilakshmitulasi@gmail.com
        </p>
      </div>
    </header>
  );
}