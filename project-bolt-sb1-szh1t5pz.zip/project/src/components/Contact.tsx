import React from 'react';
import { Phone, Mail, Linkedin, Github } from 'lucide-react';

export function Contact() {
  return (
    <section className="bg-white p-6 rounded-lg shadow-md mb-6">
      <h2 className="text-2xl font-bold mb-4 text-gray-800">Contact Information</h2>
      <div className="space-y-3">
        <div className="flex items-center">
          <Phone className="w-5 h-5 mr-2 text-gray-600" />
          <p>7981110354</p>
        </div>
        <div className="flex items-center">
          <Mail className="w-5 h-5 mr-2 text-gray-600" />
          <p>arepallilakshmitulasi@gmail.com</p>
        </div>
        <div className="flex items-center">
          <Linkedin className="w-5 h-5 mr-2 text-gray-600" />
          <p>linkedin.com/in/tulasi-arepalli</p>
        </div>
        <div className="flex items-center">
          <Github className="w-5 h-5 mr-2 text-gray-600" />
          <p>github.com/tulasi</p>
        </div>
      </div>
    </section>
  );
}